using NUnit.Framework;
using BOATProj;
using BOATProj.Models;
using System;

namespace nUnitBoatProject
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void ToCheckTheAmountPayedForRent()
        {
            DateTime st = DateTime.Now;
            DateTime ed = DateTime.Now.AddDays(3.5);
            double HrlyRate = 100;
            Business b = new Business();
            double amt = b.GetFinalAmount(st, HrlyRate);
            Assert.AreEqual(100, amt);
        }
    }
}