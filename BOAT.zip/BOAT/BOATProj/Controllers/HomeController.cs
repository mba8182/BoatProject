﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using BOATProj.Models;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;

namespace BOATProj.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        private readonly IConfiguration _configuration;
        Business oBus;

        static HomeController()
        {

        }

        public HomeController(IConfiguration configuration)
        {


            if (_configuration == null)
            {
                _configuration = configuration;
                oBus = new Business(_configuration);
            }
        }

        //public HomeController(ILogger<HomeController> logger)
        //{
        //    _logger = logger;
        //}

        public IActionResult Index()
        {
            return View("Index");
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult Login()
        {
            return View();
        }

        public IActionResult CreateBoat()
        {
            return View();
        }

        public IActionResult AssignBoatCustomer()
        {
            return View();
        }

        public IActionResult AssignCustomerBoat()
        {
            return View();
        }

        [HttpGet]
        public JsonResult DoLogin(string uid, string password)
        {
            if (oBus.IsUserAuths(uid, password))
            {
                return Json(new { success = "true" });
            }
            else
            {
                return Json(new { success = "false", success1 = "false" });
            }
        }

        public ViewResult AddBoat()
        {
            return View();
        }

        [HttpPost]
        public JsonResult SaveAddBoat(string boatName, string HrsRates)
        {
            Boat boat = oBus.AddBoat(boatName, HrsRates);
            return Json(new { BoatID = boat.BoatID, IsSuccessErr = boat.IsSuccessErr, SuccessError = boat.SuccessError });
        }


        [HttpPost]
        public JsonResult GetcustBoat()
        {
            BoatCustomer b = oBus.GetBoatCustomer();
            var cust = Newtonsoft.Json.JsonConvert.SerializeObject(b.custs).ToString();
            var boats = Newtonsoft.Json.JsonConvert.SerializeObject(b.bots).ToString();

            return Json(new { cust = cust, boats = boats });
        }

        [HttpPost]
        public JsonResult AssignBoatCust(string boatid, string custid)
        {
            Tuple<String, String, string> t = oBus.AssignBoatCustomer(boatid, custid);
            //var cust = Newtonsoft.Json.JsonConvert.SerializeObject(b.custs).ToString();
            //var boats = Newtonsoft.Json.JsonConvert.SerializeObject(b.bots).ToString();

            return Json(new { IsBoatRented = t.Item1, Msg = t.Item2, CustName = t.Item3 });

        }



        public ViewResult ReturnABoat()
        {
            return View();
        }

        
        [HttpPost]
        public JsonResult GetRentedBoats()
        {
            List<BoatCustomerHrly> boatCustomerHrly = oBus.GetRentedBoats();
            var _boatCustomerHrly = Newtonsoft.Json.JsonConvert.SerializeObject(boatCustomerHrly);


            return Json(new { rentedBoats = _boatCustomerHrly });
        }

        // Error Handling is used in this funcation.
        [HttpPost]
        public JsonResult SaveReturnBoat(string boatId)
        {
            Tuple<string,string> oSavedReturnedMsg = oBus.SaveReturnBoat(boatId);
            var _boatCustomerHrly = Newtonsoft.Json.JsonConvert.SerializeObject(oSavedReturnedMsg);
            return Json(new { Issuccess = oSavedReturnedMsg.Item1 ,mgs= oSavedReturnedMsg.Item2 });
        }

        public ViewResult DeRegisteBoat()
        {
            return View();
        }

        public JsonResult GetAllActiveBoats()
        {
            List<Boats> lstBoats = oBus.GetAllActiveBoats();
            var _boatCustomerHrly = Newtonsoft.Json.JsonConvert.SerializeObject(lstBoats);
            return Json(new { lstActiveBoats = _boatCustomerHrly });
        }

        [HttpPost]
        public JsonResult DeRegisterBoat(string boatId)
        {
            Tuple<string, string> oSavedReturnedMsg = oBus.DeRegisterBoat(boatId);
            var _boatCustomerHrly = Newtonsoft.Json.JsonConvert.SerializeObject(oSavedReturnedMsg);
            return Json(new { Issuccess = oSavedReturnedMsg.Item1, mgs = oSavedReturnedMsg.Item2 });
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
