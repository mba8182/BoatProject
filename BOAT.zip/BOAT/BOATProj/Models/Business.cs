﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace BOATProj.Models
{
    public class Business
    {
        IConfiguration config1;

        public Business(IConfiguration config)
        {
            config1 = config;
        }

        public Business()
        {
        }

        public Boolean IsUserAuths(string userName, string uid)
        {
            string myDb1ConnectionString = config1.GetConnectionString("DefaultConnection");
            using (SqlConnection con = new SqlConnection(myDb1ConnectionString))
            {

                string query = "IsUserExist";         //Stored Procedure name   
                SqlCommand com = new SqlCommand(query, con);  //creating  SqlCommand  object  
                com.CommandType = CommandType.StoredProcedure;  //here we declaring command type as stored Procedure  

                //adding paramerters to  SqlCommand below *\  
                com.Parameters.AddWithValue("@UserID", userName);        //first Name  
                com.Parameters.AddWithValue("@Password", uid);     //middle Name  

                SqlParameter outputIdParam = new SqlParameter("@IsTrue", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                com.Parameters.Add(outputIdParam);

                com.Connection.Open();

                com.ExecuteNonQuery();

                Object IsTrue = outputIdParam.Value;

                bool IsValidUser = IsTrue.ToString() != "1" ? false : true;

                com.Connection.Close();
                return IsValidUser;

            }

        }

        public Boat AddBoat(string boatName, string HrsRate)
        {
            string myDb1ConnectionString = config1.GetConnectionString("DefaultConnection");
            Boat boat = null;
            using (SqlConnection con = new SqlConnection(myDb1ConnectionString))
            {
                string query = "ADDBOAT";         //Stored Procedure name   
                SqlCommand com = new SqlCommand(query, con);  //creating  SqlCommand  object  
                com.CommandType = CommandType.StoredProcedure;  //here we declaring command type as stored Procedure  

                //adding paramerters to  SqlCommand below *\  
                com.Parameters.AddWithValue("@BOATNAME", boatName);        //first Name  
                com.Parameters.AddWithValue("@HOURRATE", HrsRate);     //middle Name  

                SqlParameter outputIdParam = new SqlParameter("@IsTrue", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };
                com.Parameters.Add(outputIdParam);

                SqlParameter successErr = new SqlParameter("@SuccessErrorMgs", SqlDbType.VarChar, 2042)
                {
                    Direction = ParameterDirection.Output
                };

                com.Parameters.Add(successErr);

                SqlParameter BoatId = new SqlParameter("@BoatId", SqlDbType.Int)
                {
                    Direction = ParameterDirection.Output
                };

                com.Parameters.Add(BoatId);


                com.Connection.Open();

                com.ExecuteNonQuery();

                Object IsTrue = outputIdParam.Value;
                Object SuccErr = successErr.Value;
                Object boatId = BoatId.Value;

                com.Connection.Close();

                if (IsTrue.ToString() == "1")
                {
                    boat = new Boat { BoatID = boatId.ToString(), IsSuccessErr = IsTrue.ToString(), SuccessError = SuccErr.ToString() };
                }
                else if (IsTrue.ToString() == "0")
                {
                    boat = new Boat { BoatID = boatId.ToString(), IsSuccessErr = IsTrue.ToString(), SuccessError = SuccErr.ToString() };
                }

                return boat;
            }
        }

        public BoatCustomer GetBoatCustomer()
        {
            string myDb1ConnectionString = config1.GetConnectionString("DefaultConnection");
            BoatCustomer lstbotcust = new BoatCustomer();
            using (SqlConnection connection =
            new SqlConnection(myDb1ConnectionString))
            {
                DataSet ds = new DataSet();
                SqlDataAdapter adapter = new SqlDataAdapter();
                adapter.SelectCommand = new SqlCommand("GET_CUSTOMER_BOATNAME", connection);
                adapter.Fill(ds);

                Boats bts;
                Customers cust;
                if (ds.Tables.Count > 1)
                {
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        cust = new Customers();
                        cust.CustId = row["CustomerId"].ToString();
                        cust.CustName = row["CustName"].ToString();
                        lstbotcust.custs.Add(cust);

                    }

                    foreach (DataRow row in ds.Tables[1].Rows)
                    {
                        bts = new Boats();
                        bts.BoatID = row["BoatId"].ToString();
                        bts.BoatName = row["BoatName"].ToString();
                        lstbotcust.bots.Add(bts);
                    }
                }
            }
            return lstbotcust;
        }

        public Tuple<string, string, string> AssignBoatCustomer(string boatId, string custId)
        {
            Tuple<string, string, string> t = null;
            string myDb1ConnectionString = config1.GetConnectionString("DefaultConnection");
            BoatCustomer lstbotcust = new BoatCustomer();
            using (SqlConnection connection = new SqlConnection(myDb1ConnectionString))
            {
                DataSet ds = new DataSet();
                SqlDataAdapter adapter = new SqlDataAdapter();

                adapter.SelectCommand = new SqlCommand("proc_BoatCustomerRentTranscation", connection);
                adapter.SelectCommand.CommandType = CommandType.StoredProcedure;

                adapter.SelectCommand.Parameters.Add("@BoatId", SqlDbType.Int).Value = Convert.ToInt32(boatId);
                adapter.SelectCommand.Parameters.Add("@CustomerId", SqlDbType.Int).Value = Convert.ToInt32(custId);

                adapter.Fill(ds);

                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    string IsBoatRented = row["IsBoatRented"].ToString();
                    string Msg = row["Msg"].ToString();
                    String custName = row["CustName"].ToString();
                    t = Tuple.Create(IsBoatRented, Msg, custName);

                }

            }
            return t;
        }

        public List<BoatCustomerHrly> GetRentedBoats()
        {
            string myDb1ConnectionString = config1.GetConnectionString("DefaultConnection");
            List<BoatCustomerHrly> lstBoatCustomerHrly = new List<BoatCustomerHrly>();
            BoatCustomerHrly boatCustomerHrly = null;

            using (SqlConnection connection =
            new SqlConnection(myDb1ConnectionString))
            {
                DataSet ds = new DataSet();
                SqlDataAdapter adapter = new SqlDataAdapter();
                adapter.SelectCommand = new SqlCommand("GetRentedBoats", connection);
                adapter.Fill(ds);

                if (ds.Tables.Count > 0)
                {
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        boatCustomerHrly = new BoatCustomerHrly();
                        boatCustomerHrly.BoatID = row["BoatId"].ToString();
                        boatCustomerHrly.BoatName = row["BoatName"].ToString();
                        boatCustomerHrly.CustId = row["CustomerId"].ToString();
                        boatCustomerHrly.CustName = row["CustName"].ToString();
                        DateTime BoatRentStartDate = Convert.ToDateTime(row["BoatRentStartDate"]);
                        Double HowerlyRate = Convert.ToDouble(row["HowerlyRate"]);
                        boatCustomerHrly.HrlyRates = row["HowerlyRate"].ToString();
                        boatCustomerHrly.FinalAmountToPay = GetFinalAmount(BoatRentStartDate, HowerlyRate);
                        lstBoatCustomerHrly.Add(boatCustomerHrly);
                    }
                }
            }
            return lstBoatCustomerHrly;
        }

        public Tuple<String, String> SaveReturnBoat(string boatID)
        {
            Tuple<String, String> t = null; ;
            try
            {
                string myDb1ConnectionString = config1.GetConnectionString("DefaultConnection");

                using (SqlConnection connection = new SqlConnection(myDb1ConnectionString))
                {
                    DataSet ds = new DataSet();
                    SqlDataAdapter adapter = new SqlDataAdapter();
                    adapter.SelectCommand = new SqlCommand("proc_Return_ABoat_Customer", connection);
                    adapter.SelectCommand.CommandType = CommandType.StoredProcedure;
                    adapter.SelectCommand.Parameters.Add("@BoatId", SqlDbType.Int).Value = Convert.ToInt32(boatID);
                    adapter.Fill(ds);

                    if (ds.Tables.Count > 0)
                    {
                        foreach (DataRow row in ds.Tables[0].Rows)
                        {
                            String IsReturnedSuccess = row["IsReturnedSuccess"].ToString();
                            String MSG = row["MSG"].ToString();
                            t = Tuple.Create(IsReturnedSuccess, MSG);
                        }
                    }
                }
                return t;
            }
            catch (Exception ex)
            {
                return Tuple.Create("0", ex.Message);
            }
        }

        public Tuple<String, String> DeRegisterBoat(string boatId)
        {

            Tuple<String, String> t = null; ;
            try
            {
                string myDb1ConnectionString = config1.GetConnectionString("DefaultConnection");

                using (SqlConnection connection = new SqlConnection(myDb1ConnectionString))
                {
                    DataSet ds = new DataSet();
                    SqlDataAdapter adapter = new SqlDataAdapter();
                    adapter.SelectCommand = new SqlCommand("proc_DeRegisterBoat", connection);
                    adapter.SelectCommand.CommandType = CommandType.StoredProcedure;
                    adapter.SelectCommand.Parameters.Add("@BoatId", SqlDbType.Int).Value = Convert.ToInt32(boatId);
                    adapter.Fill(ds);

                    if (ds.Tables.Count > 0)
                    {
                        foreach (DataRow row in ds.Tables[0].Rows)
                        {
                            String IsDeregister = row["IsDeregister"].ToString();
                            String MSG = row["MSG"].ToString();
                            t = Tuple.Create(IsDeregister, MSG);
                        }
                    }
                }
                return t;
            }
            catch (Exception ex)
            {
                return Tuple.Create("0", ex.Message);
            }
        }

        public double GetFinalAmount(DateTime stDate, double HourlyRate)
        {
            DateTime sd = stDate;
            DateTime ed = DateTime.Now;

            double diffInMin = (ed - sd).TotalMinutes;
            Double diffInMinBy60 = diffInMin / 60;
            string[] splitHrsMin = diffInMinBy60.ToString().Split('.');
            int hrs = Convert.ToInt32(splitHrsMin[0]);
            Int64 mins = Convert.ToInt64(splitHrsMin[1]);

            if (mins > 0)
            {
                hrs = hrs + 1; // Plus one Hrs
            }


            return hrs * HourlyRate;
        }

        public List<Boats> GetAllActiveBoats()
        {
            List<Boats> lstboats = new List<Boats>();
            string myDb1ConnectionString = config1.GetConnectionString("DefaultConnection");
            List<BoatCustomerHrly> lstBoatCustomerHrly = new List<BoatCustomerHrly>();
            BoatCustomerHrly boatCustomerHrly = null;
            Boats b = null;
            using (SqlConnection connection =
            new SqlConnection(myDb1ConnectionString))
            {
                DataSet ds = new DataSet();
                SqlDataAdapter adapter = new SqlDataAdapter();
                adapter.SelectCommand = new SqlCommand("GetAllActiveBoats", connection);
                adapter.Fill(ds);

                if (ds.Tables.Count > 0)
                {
                    foreach (DataRow row in ds.Tables[0].Rows)
                    {
                        b = new Boats();
                        b.BoatID = row["BoatId"].ToString();
                        b.BoatName = row["BoatName"].ToString();

                        lstboats.Add(b);
                    }
                }
            }
            return lstboats;
        }
    }
}
