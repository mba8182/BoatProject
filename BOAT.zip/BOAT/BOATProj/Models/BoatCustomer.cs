﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BOATProj.Models
{
    public class BoatCustomer
    {
        public List<Boats> bots = new List<Boats>();
        public List<Customers> custs = new List<Customers>();
    }

    public class Boats
    {
        public string BoatID { get; set; }
        public string BoatName { get; set; }

    }

    public class Customers
    {
        public string CustId { get; set; }
        public string CustName { get; set; }
    }

    public class BoatCustomerHrly
    {
        public string BoatID { get; set; }
        public string BoatName { get; set; }
        public string CustId { get; set; }
        public string CustName { get; set; }
        public string HrlyRates { get; set; }

        public double FinalAmountToPay { get; set; }
    }

}