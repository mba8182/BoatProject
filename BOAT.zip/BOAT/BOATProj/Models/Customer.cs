﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BOATProj.Models
{
    public class Customer
    {
        public string CustId { get; set; }
        public string CustName { get; set; }
    }
}
