﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BOATProj.Models
{
    public class Boat
    {
        public string BoatID { get; set; }
        public string BoatName { get; set; }
        public string HrsRate { get; set; }

        public string IsSuccessErr { get; set; }
        public string SuccessError { get; set; }
    }
}
