﻿
var myApp = angular.module('myFormApp', []);

myApp.controller('myCtrlBOAT', function ($scope, $http) {

    //debugger;
    $scope.custModel = {};
    //$scope.message = '';
    //$scope.result = "color-default";
    //$scope.isViewLoading = false;
    //$scope.ListCustomer = null;

    $scope.myFunc = function () {
        //debugger;
    };

    //******=========Get All Customer=========******
    $scope.IsLoginTrue = function () {
        //debugger;
        var param = $scope.custModel;
        var uid = $scope.custModel.name;
        var password = $scope.custModel.password;

        try {

            $http.get(
                '/Home/DoLogin?uid=' + uid + "&password=" + password
            )
                .then(function (response) {
                    //debugger;
                    if (response.data.success == "true") {
                        window.location.href = "/Home/Index";

                    }
                    else {
                        alert("Invalid User Id Or Password.");

                    }
                });

        } catch (e) {
            //debugger;
        }


    };

    $scope.BoatModel = {};
    $scope.isEnableDesable = false;

    $scope.AddBoat = function () {
        //debugger;
        var boatName = $scope.BoatModel.BoatName;
        var HrsRates = $scope.BoatModel.HrsRates;

        try {

            $http.post(
                '/Home/SaveAddBoat?boatName=' + boatName + "&HrsRates=" + HrsRates
            )
                .then(function (response) {
                    //debugger;

                    //isSuccessErr	"0"	String
                    //successError	"Boat Name Already Exist"	String


                    if (response.data.isSuccessErr == "0") {
                        //window.location.href = "/Home/Index";
                        $scope.isEnableDesable = false;
                        alert(response.data.successError);
                    }
                    else if (response.data.isSuccessErr == "1") {

                        //debugger;
                        $scope.isEnableDesable = true;
                        //$scope.Message = response.data.successError + "Boat No :: " + response.data.boatID;
                        alert(response.data.successError + "Boat No :: " + response.data.boatID);
                    }
                });

        } catch (e) {
            //debugger;
        }


    };


    //====================================

    //$scope.customer = [
    //    { id: '1', name: 'Option A' },
    //    { id: '2', name: 'Option B' },
    //    { id: '3', name: 'Option C' }
    //]

    //$scope.data = {
    //    model: null,
    //    availableOptions: [
    //        { id: '1', name: 'Option A' },
    //        { id: '2', name: 'Option B' },
    //        { id: '3', name: 'Option C' }
    //    ]
    //};

   // $scope.DefaultLabel = "Loading.....";

        $http.post(
            '/Home/GetcustBoat'
        ).then(function (response) {
            //debugger;

            //isSuccessErr	"0"	String
            //successError	"Boat Name Already Exist"	String

            $scope.DefaultLabel = "Please Select";
            //window.location.href = "/Home/Index";
            $scope.Customers = JSON.parse(response.data.cust);
            $scope.Boats = JSON.parse(response.data.boats);
            //$scope.data = {
            //    model: null,
            //    availableOptions: response.data.data

            //};

        });

    $scope.AssignBoatCustomer = function () {
        //debugger;
       
        var custids = $scope.selectedItemvalueCust;
        var boatid = $scope.selectedItemvalueBoat;
        try {

            $http.post(
                '/Home/AssignBoatCust?boatid=' + boatid + "&custid=" + custids
            )
                .then(function (response) {
                    //debugger;

                    //isSuccessErr	"0"	String
                    //successError	"Boat Name Already Exist"	String
                    $scope.DefaultLabel1 = "Please Select"

                    if (response.data.isBoatRented == "1") {
                        //window.location.href = "/Home/Index";
                        $scope.isEnableDesable = false;
                        var mgs = response.data.msg + " [" + response.data.custName + "] ";
                        alert(mgs);
                    }
                    else if (response.data.isBoatRented == "0") {

                       // debugger;
                        $scope.isEnableDesable = true;
                        //$scope.Message = response.data.successError + "Boat No :: " + response.data.boatID;
                        alert(response.data.msg );
                    }
                });

        } catch (e) {
            //debugger;
        }
    };


    $scope.MapCustomerBoat = function () {
        //debugger;
        var boatid = $scope.BoatModel.BoatName;
        var custid = $scope.BoatModel.HrsRates;

        try {

            $http.post(
                '/Home/SaveAddBoat?boatid=' + boatName + "&custid=" + HrsRates
            )
                .then(function (response) {
                    //debugger;

                    //isSuccessErr	"0"	String
                    //successError	"Boat Name Already Exist"	String


                    if (response.data.isSuccessErr == "0") {
                        //window.location.href = "/Home/Index";
                        $scope.isEnableDesable = false;
                        alert(response.data.successError);
                    }
                    else if (response.data.isSuccessErr == "1") {

                        //debugger;
                        $scope.isEnableDesable = true;
                        //$scope.Message = response.data.successError + "Boat No :: " + response.data.boatID;
                        alert(response.data.successError + "Boat No :: " + response.data.boatID);
                    }
                });

        } catch (e) {
           // debugger;
        }


    };

});




var myApp = angular.module('myApp', []);
//===== New Controller
myApp.controller('myCTRL', function ($scope, $http) {

    //debugger;
    $scope.custModel = {};
   
    $http.post(
        '/Home/GetRentedBoats'
    ).then(function (response) {
        //debugger;

        //isSuccessErr	"0"	String
        //successError	"Boat Name Already Exist"	String

        $scope.DefaultLabel1 = "Please Select";
        $scope.Boats = JSON.parse(response.data.rentedBoats);
        //$scope.data = {
        //    model: null,
        //    availableOptions: response.data.data

        //};

    });


    $scope.SaveReturnBoat = function () {
       // debugger;
        //var boatid = $scope.BoatModel.BoatName;
        //var custid = $scope.BoatModel.HrsRates;
        var boatid = $scope.selectedItemvalueBoat;
        try {

            $http.post(
                '/Home/SaveReturnBoat?boatId=' + boatid
            )
                .then(function (response) {
                   // debugger;

                    if (response.data.issuccess == "1") {
                      
                        alert(response.data.mgs);
                    }
                    else if (response.data.issuccess == "0") {

                        //debugger;
                        
                        
                        alert(response.data.mgs);
                    }
                    else {
                        alert('Some thing happned wrong please contact admin.')
                    }
                });

        } catch (e) {
           // debugger;
        }
    }

   

});






var myApp = angular.module('myAppd', []);
//===== New Controller
myApp.controller('myCTRLc', function ($scope, $http) {

    //debugger;
    $scope.custModel = {};


    $http.post(
        '/Home/GetcustBoat'
    ).then(function (response) {
        //debugger;

   
        $scope.Customers = JSON.parse(response.data.cust);
        $scope.Boats = JSON.parse(response.data.boats);
       

    });

    $http.post(
        '/Home/GetRentedBoats'
    ).then(function (response) {
        //debugger;

        //isSuccessErr	"0"	String
        //successError	"Boat Name Already Exist"	String

        $scope.DefaultLabel1 = "Please Select";
        $scope.Boats = JSON.parse(response.data.rentedBoats);
        //$scope.data = {
        //    model: null,
        //    availableOptions: response.data.data

        //};

    });


    $scope.SaveReturnBoat = function () {
       // debugger;
        //var boatid = $scope.BoatModel.BoatName;
        //var custid = $scope.BoatModel.HrsRates;
        var boatid = $scope.selectedItemvalueBoat;
        try {

            $http.post(
                '/Home/SaveReturnBoat?boatId=' + boatid
            )
                .then(function (response) {
                    //debugger;

                    if (response.data.issuccess == "1") {

                        alert(response.data.mgs);
                    }
                    else if (response.data.issuccess == "0") {

                       // debugger;


                        alert(response.data.mgs);
                    }
                    else {
                        alert('Some thing happned wrong please contact admin.')
                    }
                });

        } catch (e) {
            //debugger;
        }
    }

    $scope.DeRegisterBoat = function () {
        //debugger;
        //var boatid = $scope.BoatModel.BoatName;
        //var custid = $scope.BoatModel.HrsRates;
        var boatid = $scope.selectedItemvalueBoat;
        try {

            $http.post(
                '/Home/DeRegisterBoat?boatId=' + boatid
            )
                .then(function (response) {
                   // debugger;

                    if (response.data.issuccess == "1") {

                        alert(response.data.mgs);
                    }
                    else if (response.data.issuccess == "0") {

                        //debugger;
                        //

                        alert(response.data.mgs);
                    }
                    else {
                        alert('Some thing happned wrong please contact admin.')
                    }
                });

        } catch (e) {
            //debugger;
        }
    }



});


//===== 3rd ======

var myApp = angular.module('myAppdS', []);
myApp.controller('myCTRLS', function ($scope, $http) {

    //debugger;
    $scope.custModel = {};

    $http.post(
        '/Home/GetAllActiveBoats'
    ).then(function (response) {
        //debugger;

        //isSuccessErr	"0"	String
        //successError	"Boat Name Already Exist"	String

       // $scope.DefaultLabel1 = "Please Select";
        $scope.Boats = JSON.parse(response.data.lstActiveBoats);
        //$scope.data = {
        //    model: null,
        //    availableOptions: response.data.data

        //};

    });


    $scope.DeRegisterBoat = function () {
        //debugger;
        //var boatid = $scope.BoatModel.BoatName;
        //var custid = $scope.BoatModel.HrsRates;
        var boatid = $scope.selectedItemvalueBoat;
        try {

            $http.post(
                '/Home/DeRegisterBoat?boatId=' + boatid
            )
                .then(function (response) {
                    // debugger;

                    if (response.data.issuccess == "1") {

                        alert(response.data.mgs);
                    }
                    else if (response.data.issuccess == "0") {

                        //debugger;
                        //

                        alert(response.data.mgs);
                    }
                    else {
                        alert('Some thing happned wrong please contact admin.')
                    }
                });

        } catch (e) {
            //debugger;
        }
    }



});